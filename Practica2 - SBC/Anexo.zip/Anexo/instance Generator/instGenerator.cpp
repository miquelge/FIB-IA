#include <iostream>
#include <stdlib.h>
#include <vector>
#include <algorithm> //per replace " " --> "_"
#include <map>
using namespace std;
 
void newAlternCity(string name);
void newTouristicCity(string name);
void newInterestPoint(string name, string city);
void newHotel(string name, string city);
void newContinent(string name);
void addCities(string continent);
void addHotels(string city);
void addIPoints(string city);

const int HOTEL_MAX = 200;
const int IPOINT_MAX = 200;

string continents[] = {"Oceania", "Asia", "Europe", "South America", "North America", "Africa", "Antarctica"};
string touristicCities[] = {/* Oceania */ "Melbourne!!Oceania", "Sidney!!Oceania", "Wellington!!Oceania",

							/* Asia */ "Beijing!!Asia", "Taiwan!!Asia", "Tokio!!Asia", "Nova Dheli!!Asia",

							/* Europe */ "Paris!!Europe", "London!!Europe", "Berlin!!Europe", "Dublin!!Europe",
							"Edinburgh!!Europe", "Moscow!!Europe",
							"Krakow!!Europe", "Venice!!Europe","Saint Petersburg!!Europe", "Istanbul!!Europe",
							"Rome!!Europe",

							/* South America */ "Caracas!!South America", "Rio de Janeiro!!South America",
							"La Habana!!South America", "Medellin!!South America", "Cali!!South America"

							/* North America */ "Washington DC!!North America", "New York!!North America",

							/* Africa */

							/* Antarctica */ 
							};
string alternativeCities[] = {"Girona!!Europe", "Sevilla!!Europe", "Touloise!!Europe", "Cuba!!South America"};

string hotel1[] = {"Hotel", "Hostel", "Residence", "Apartments", "Resort", "Villa"};
string hotel2[] = {"Lollipop", "Paradise", "Single Land", "Emperor", "Relax", "Chill", "Sky", "Arabiga", "NH", "Delphin"};

string ipoint1[] = {"Statue", "Square", "Museum", "Church", "Castle"};
string ipoint2[] = {"Superman", "Diversity", "Lenin", "Spaghetti monster", "Leo Messi", "Power Rangers", "Snoop Dog", "Mr. Jagger"};

map<string, vector<string> > cityHotelsMap;
map<string, vector<string> >::iterator itHot;
map<string, vector<string> > cityIPointsMap;
map<string, vector<string> >::iterator itPoint;

int main() {


	// Create hotel instances 
	cout << ";*************** HOTELS ***************" << endl;
	int hotelID = 0;
	int size, rnd;
	string name, city;
	while (hotelID < HOTEL_MAX) {
		name = hotel1[rand() % 5] + " " + hotel2[rand() % 6] + " " + to_string(hotelID++);
		if ((rand() % 1) == 0) {
			size = (sizeof(touristicCities)/sizeof(*touristicCities));
			rnd = rand() % size;
			city = touristicCities[rnd].substr(0, touristicCities[rnd].find("!!"));
		}
		else {
			size = (sizeof(alternativeCities)/sizeof(*alternativeCities));
			rnd = rand() % size;
			city = alternativeCities[rnd].substr(0, alternativeCities[rnd].find("!!"));
		}
		newHotel(name, city);
	} 

	// Create interest point instances 
	cout << ";*************** INTEREST POINTS ***************" << endl;
	int ipointID = 0;
	while (ipointID < IPOINT_MAX) {
		name = ipoint1[rand() % 5] + " of " + ipoint2[rand() % 6] + " " + to_string(ipointID++);
		if ((rand() % 1) == 0) {
			size = (sizeof(touristicCities)/sizeof(*touristicCities));
			rnd = rand() % size;
			city = touristicCities[rnd].substr(0, touristicCities[rnd].find("!!"));
		}
		else {
			size = (sizeof(alternativeCities)/sizeof(*alternativeCities));
			rnd = rand() % size;
			city = alternativeCities[rnd].substr(0, alternativeCities[rnd].find("!!"));
		}
		newInterestPoint(name, city);
	} 

	//Create continent instances
	cout << ";*************** CONTINENTS ***************" << endl;
	for (int i = 0; i < (sizeof(continents)/sizeof(*continents)); ++i) 
		newContinent(continents[i]);
	cout << endl << endl;

	//Create touristic cities instances
	cout << ";*************** TOURISTIC CITIES ***************" << endl;
	for (int i = 0; i < (sizeof(touristicCities)/sizeof(*touristicCities)); ++i) 
		newTouristicCity(touristicCities[i]);
	cout << endl << endl;

	//Create alternative cities instances
	cout << ";*************** ALTERNATIVE CITIES ***************" << endl;
	for (int i = 0; i < (sizeof(alternativeCities)/sizeof(*alternativeCities)); ++i) 
		newAlternCity(alternativeCities[i]);
	cout << endl << endl;
}

void newAlternCity(string name) {
	int ponQual = rand() % 100;
	name = name.substr(0, name.find("!!"));
	string objName = name;
	replace( objName.begin(), objName.end(), ' ', '_');

	cout << "([" << objName << "] of City" << endl << endl;
	cout << "(cityType alternative)" << endl;
	addHotels(name);
	addIPoints(name);
	cout << "(lifeQuality ";
		if (ponQual < 30) cout << "lowCost)" << endl;
		else if (ponQual < 80) cout << "regular)" << endl;
		else cout << "expensive)" << endl;
	cout << "(NameCity \"" << name << "\")" << endl;
	//cout << "TODO: travByCar/Train/Plane/Boat" << endl;
	cout << ")" << endl << endl << endl;
}

void newTouristicCity(string name) {
	int ponQual = rand() % 100;
	name = name.substr(0, name.find("!!"));
	string objName = name;
	replace( objName.begin(), objName.end(), ' ', '_');

	cout << "([" << objName << "] of City" << endl << endl;
	cout << "(cityType touristic)" << endl;
	addHotels(name);
	addIPoints(name);
	cout << "(lifeQuality ";
		if (ponQual < 10) cout << "lowCost)" << endl;
		else if (ponQual < 35) cout << "regular)" << endl;
		else cout << "expensive)" << endl;
	cout << "(NameCity \"" << name << "\")" << endl;
	//cout << "TODO: travByCar/Train/Plane/Boat" << endl;
	cout << ")" << endl << endl << endl;
}

void newInterestPoint(string name, string city) {
	int ponCult = rand() % 100;
	int ponFam  = rand() % 100;
	int ponAgeJ = rand() % 100;
	int ponAgeS = rand() % 100;
	int ponAgeV = rand() % 100;

	string objName = name;
	replace( objName.begin(), objName.end(), ' ', '_');

	itPoint = cityIPointsMap.find(city);
	if (itPoint != cityIPointsMap.end())
		cityIPointsMap[city].push_back(objName);
	else {
		vector<string> v;
		v.push_back(objName);
		cityIPointsMap[city] = v;
	}

	cout << "([" << objName << "] of interestPoint" << endl << endl;
	cout << "( cultural ";
		if (ponCult > 40) cout << "FALSE)" << endl;
		else cout << "TRUE)" << endl;
	cout << "( forFamilies ";
		if (ponFam > 30) cout << "FALSE)" << endl;
		else cout << "TRUE)" << endl;
	cout << "(Name \"" << name << "\")" << endl;
	cout << "(publicAge";
	if (ponAgeJ < 33) cout << " Junior"; 
	if (ponAgeS < 33) cout << " Senior"; 
	if (ponAgeV < 33) cout << " Veteran"; 
	cout << ")" << endl;
	cout << ")" << endl << endl << endl;
}

void newHotel(string name, string city) {
	int ponQual = rand() % 100;
	string objName = name;
	replace( objName.begin(), objName.end(), ' ', '_');

	itHot = cityHotelsMap.find(city);
	if (itHot != cityHotelsMap.end())
		cityHotelsMap[city].push_back(objName);
	else {
		vector<string> v;
		v.push_back(objName);
		cityHotelsMap[city] = v;
	}

	cout << "([" << objName << "] of Hotel" << endl << endl;
	cout << "(city \"" << city << "\")" << endl;
	cout << "(NameHotel \"" << name << "\")" << endl;
	cout << "(price ";
		if (ponQual < 33) cout << "lowCost)" << endl;
		else if (ponQual < 66) cout << "regular)" << endl;
		else cout << "expensive)" << endl;
	cout << ")" << endl << endl << endl;
}

void newContinent(string name) {

	string objName = name;
	replace( objName.begin(), objName.end(), ' ', '_');
	cout << "([" << objName << "] of Continent" << endl << endl;
	cout << "(hasCities " << endl;
	addCities(name);
	cout << "(NameContinent \"" << name << "\")" << endl; 
	cout << ")" << endl << endl << endl;
}

void addCities(string continent) {
	string city, cityCont, s;

	//touristic cities
	for (int i = 0; i < (sizeof(touristicCities)/sizeof(*touristicCities)); ++i) {
		s = touristicCities[i];
		city = s.substr(0, s.find("!!"));
		cityCont = s.substr(s.find("!!")+2, s.length());
		
		string objCity = city;
		replace( objCity.begin(), objCity.end(), ' ', '_');
		if (cityCont == continent)
			cout << "	[" + objCity + "]" << endl;
	}

	//alternative cities
	for (int i = 0; i < (sizeof(alternativeCities)/sizeof(*alternativeCities)); ++i) {
		s = alternativeCities[i];
		city = s.substr(0, s.find("!!"));
		cityCont = s.substr(s.find("!!")+2, s.length());
		
		string objCity = city;
		replace( objCity.begin(), objCity.end(), ' ', '_');
		if (cityCont == continent)
			cout << "	[" + objCity + "]" << endl;
	}

	cout << ")" << endl;
}

void addHotels(string city) {
	vector<string> hotels = cityHotelsMap[city];
	cout << "(hasHotels" << endl;
	for (int i = 0; i < hotels.size(); ++i) {
		cout << "	[" << hotels[i] << "]" << endl;
	}
	cout << ")" << endl;
}

void addIPoints(string city) {
	vector<string> ipoints = cityIPointsMap[city];
	cout << "(hasInterestPoints" << endl;
	for (int i = 0; i < ipoints.size(); ++i) {
		cout << "	[" << ipoints[i] << "]" << endl;
	}
	cout << ")" << endl;
}
